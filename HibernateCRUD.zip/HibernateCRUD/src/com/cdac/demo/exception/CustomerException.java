package com.cdac.demo.exception;

public class CustomerException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5613767351451605370L;

	public CustomerException() {
		// TODO Auto-generated constructor stub
	}

	public CustomerException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public CustomerException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public CustomerException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public CustomerException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

}
